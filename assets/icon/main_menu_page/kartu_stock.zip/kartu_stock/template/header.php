<div id="header">




	<div id="logo">

		<a href=""><img src="../images/Caawiye.png" alt="" align='center'/></a>

	</div>

	<div id="logo">

	</div>


</div> <!--DHAMAADKA hedaerka-->