<section id="secondary_bars">

	<nav><!-- Defining the navigation menu -->
		<ul>
			<li class="icn_tags"><a href="../index.php"><img src="../images/rekap-home.png" alt="photo" width="40" height="40">Home</a></li>

			<li class="icn_tags"><a href="../shorcut_search.php"><img src="../images/rekap2.png" alt="photo" width="40" height="40">Rekap Material</a></li>        
			<li class="icn_tags"><a href="../rekap_upah_spu_search.php"><img src="../images/rekap1.png" alt="photo" width="40" height="40">Rekap Upah dan SPU</a></li>
			<li class="icn_tags"><a href="../laporan_project.php"><img src="../images/rekap3.png" alt="photo" width="40" height="40">Laporan Project</a></li>
			<li class="icn_tags"><a href="<?php echo base_url() ?>rekap_stock"><img src="../images/rekap3.png" alt="photo" width="40" height="40">Rekap Stock</a></li>




		</ul>

	</nav>

</section><!-- end of secondary bar -->