<aside id="sidebar" class="column">
	<!-- Begin Search -->

	<!-- End Search -->
	<hr/>


	<h3>Backup Database</h3>
	<ul class="toggle">


		<li ><a href="../Backup.php"><img src="../images/sql.png" alt="photo" width="100" height="70" > </a></li>



	</ul>		
	<h3>Form Material:</h3>
	<ul class="toggle">


		<li class="icn_photo"><a href="../bq_search.php">Budget Material</a></li>
		<li class="icn_categories"><a href="../pr_search.php">PR List</a></li>

		<li class="icn_tags"><a href="../po_search.php">PO List IDR</a></li>
		<li class="icn_tags"><a href="../po_search_usd.php">PO List USD</a></li>

		<li class="icn_tags"><a href="../lpb_search.php">LPB Workshop List</a></li>
		<li class="icn_tags"><a href="../stock_search.php">Stock Search</a></li>
		<li class="icn_tags"><a href="../do_material_search.php">List DO LPB Material</a></li>
		<li class="icn_tags"><a href="../spu_search.php">SPU Material</a></li>







	</ul>

	<h3>Form Upah:</h3>
	<ul class="toggle">
		<li class="icn_photo"><a href="../upah_search.php">Budget Upah List</a></li>



		<li class="icn_photo"><a href="../do_search.php">DO List</a></li>
		<li class="icn_tags"><a href="../lpb_unit_search.php">LPB Unit List</a></li>
		<li class="icn_tags"><a href="../reg_search.php">Registrasi Mandor</a></li>
		<li class="icn_tags"><a href="../kasbon_search.php">Kasbon Mandor List</a></li>
		<li class="icn_tags"><a href="../opname_list_search.php">List Opname Detail</a></li>
		<li class="icn_tags"><a href="../rekap_mandor.php">Rekap Mandor</a></li>




	</ul>
	<h3>Form OverHead</h3>
	<ul class="toggle">
		<li class="icn_photo"><a href="../overhead_search.php">OverHead List</a></li>
		<li class="icn_tags"><a href="../real_overhead_search.php">Realisasi Overhead</a></li>
		<li class="icn_tags"><a href="../list_real_overhead_search.php">List Realisasi Overhead</a></li>
	</ul>

	<h3>Form</h3>
	<ul class="toggle">
		<li class="icn_photo"><a href="<?php echo base_url() ?>kartu_stock">Kartu Stok</a></li>
		<li class="icn_photo"><a href="<?php echo base_url() ?>data_stock">Data Stok</a></li>
		<li class="icn_photo"><a href="<?php echo base_url() ?>data_do_stock">DO Stock</a></li>
		<li class="icn_photo"><a href="<?php echo base_url() ?>data_surat_jalan_stock">Surat Jalan</a></li>
	</ul>



	<h3>Data Mandor</h3>
	<ul class="toggle">
		<li class="icn_photo"><a href="../mandor_search.php">Data Mandor</a></li>



	</ul>
	<h3>Konfigurasi Perusahaan:</h3>
	<ul class="toggle">

		<li class="icn_add_user"><a href="../project_list.php">Daftar Project</a></li>
		<li class="icn_tags"><a href="../add_warehouse.php">Supplier</a></li>



		<li class="icn_add_user"><a href="../Employee.php">User</a></li>

	</ul>

	<h3>Keluar</h3>
	<ul class="toggle">

		<li class=""><a href="../../logout.php"><img src="../images/logout.png" alt="photo" width="100" height="80"></a></li>
	</ul>

</aside><!-- end of sidebar -->