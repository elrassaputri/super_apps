<?php

/**
 * 
 */
class KartuStock extends Controller
{
	public function index() {

		// login::ceklogin();
		session_start();

		if(isset($_GET['cari'])){
			$cari = $_GET['cari'];
			$_SESSION["cari"] = $cari;
		}

		$per_laman = 1;
		$_SESSION["per_laman"] = $per_laman;

		if(isset($_GET['per_laman'])) {
			$per_laman = $_GET['per_laman'];
			$_SESSION["per_laman"] = $per_laman;
		}

		$laman_sekarang = 1;
		if(isset($_GET['laman'])) {
			$laman_sekarang = $_GET['laman'];
			$laman_sekarang = ($laman_sekarang > 1) ? $laman_sekarang : 1;
		}

		if(isset($cari))
			$result = M_kartu_stock::get_search($cari);
		else
			$result = self::get('kartu_stock');
		$total_data = count($result);
		$total_laman = ceil($total_data / $per_laman);
		$awal = ($laman_sekarang - 1) * $per_laman;
		if(isset($cari))			
			$data = self::searchUser($cari, $awal, $per_laman);
		else
			$data = self::get_limit('kartu_stock', $awal, $per_laman);

		self::CreatePagging('kartu_stock', $data, $total_laman, $laman_sekarang);
		// self::CreateView('data_user', $data);
	}

	public function getAdd() {
		// login::ceklogin();
		$result = self::get('supliers');
		self::CreateView('add_kartu_stock', $result);
	}

	public function add() {
		$data = array('tanggal' => $_POST['tanggal'],
					'no_sj' => $_POST['no_sj'],
					'no_lpb' => $_POST['no_lpb'],
					'nama_supplier' => $_POST['nama_supplier'],
					'masuk' => $_POST['masuk'],
					'keluar' => $_POST['keluar'],
					'saldo' => $_POST['saldo'],
					'pjg' => $_POST['pjg'],
					'qty' => $_POST['qty'],
					'ket' => $_POST['ket'] );
		M_kartu_stock::add($data);
		header('Location: '.base_url().'kartu_stock');
	}

	public function delete() {
		// login::ceklogin();
		$id = $_GET['id'];
		M_kartu_stock::delete($id);
		header('Location: '.base_url().'kartu_stock');
	}

	public function update() {
		// login::ceklogin();
		$id = $_GET['id'];
		$data = self::get_where('kartu_stock', 'id', $id);
		$result = self::get('supliers');
		self::CreateView('edit_kartu_stock', $data, $result);
	}

	public function updateAction() {
		$id = $_POST['id'];
		$data = array('tanggal' => $_POST['tanggal'],
					'no_sj' => $_POST['no_sj'],
					'no_lpb' => $_POST['no_lpb'],
					'nama_supplier' => $_POST['nama_supplier'],
					'masuk' => $_POST['masuk'],
					'keluar' => $_POST['keluar'],
					'saldo' => $_POST['saldo'],
					'pjg' => $_POST['pjg'],
					'qty' => $_POST['qty'],
					'ket' => $_POST['ket'] );
		M_kartu_stock::update($id, $data);
		header('Location: '.base_url().'kartu_stock');
	}

	public function searchUser($cari, $awal, $per_laman) {
		$data = M_kartu_stock::get_search_limit($cari, $awal, $per_laman);
		return $data;
	}
}
?>