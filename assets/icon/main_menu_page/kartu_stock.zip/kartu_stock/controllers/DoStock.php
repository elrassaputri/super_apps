<?php

/**
 * 
 */
class DoStock extends Controller
{
	public function add()
	{
		session_start();
		$_SESSION['no_do'] = '';
		if (isset($_GET['id']))
			$id = $_GET['id'];			
		else
			$id = '';

		$data_lpb = self::get('lpb');
		$data_keranjang_do_stock = self::get('do_stock_keranjang');

		if ($id != '') {
			$where_lpb = self::get_where('lpb','lpb_id',$id);
			$data_stock = array('lpb' => $data_lpb,
				'where_lpb' => $where_lpb,
				'do_stock_keranjang' => $data_keranjang_do_stock);
		} else
			$data_stock = array('lpb' => $data_lpb, 'do_stock_keranjang' => $data_keranjang_do_stock);

		// if ($_SESSION['no_do'] == '') {
		// 	$no_do = self::no_do();
		// 	$_SESSION["no_do"] = $no_do;
		// }
		
		$tanggal_do = date('Y-m-d');
		$data_form = array('lpb_id'	=> $id, 'tanggal_do' => $tanggal_do );
		self::CreateView('add_do_stock',$data_stock, $data_form);
	}

	public function no_do()
	{
		$chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
	    srand((double)microtime()*1000000);
	    $i = 0;
	    $pass = '' ;
	    while ($i <= 12) {
	    	$num = rand() % 33;
	        $tmp = substr($chars, $num, 1);
	        $pass = $pass . $tmp;
	        $i++;
	    }
	    return $pass;
	}

	public function addKeranjang()
	{
		session_start();
		if ($_POST) {
			$id_material = $_POST['material_do_id'];
			$nama_material = $_POST['material_do'];
			$kode_do_stock = $_POST['section_do'];
			$pjg_do_stock = $_POST['ukuran_do'];
			$finish_do_stock = $_POST['sat_do'];
			$budget_do_stock = $_POST['budget_do'];
			$vol_do_stock = $_POST['vol_do'];
			$type_do_stock = $_POST['type_do'];
			$ket_do_stock = $_POST['ket_do'];

			$data_keranjang_do_stock = array('lpb_material_id' => $id_material,
			'nama_material' => $nama_material,
			'kode_do_stock' => $kode_do_stock,
			'pjg_do_stock' => $pjg_do_stock,
			'finish_do_stock' => $finish_do_stock,
			'budget_do_stock' => $budget_do_stock,
			'vol_do_stock' => $vol_do_stock,
			'type_do_stock' => $type_do_stock,
			'ket_do_stock' => $ket_do_stock );

			M_do_stock::addKeranjang($data_keranjang_do_stock);
			header('Location: '.base_url().'add_do_stock');

		} else {
			echo "<script>";
			echo "alert('Gagal tambah keranjang')";
			echo "</script>";
			header('Location: '.base_url().'add_do_stock');
		}
	}

	public function deleteKeranjang()
	{
		if ($_GET['id']) {
			$id = $_GET['id'];
			M_do_stock::deleteKeranjang($id);
			header('Location: '.base_url().'add_do_stock');
		}else{
			echo "<script>";
			echo "alert('Gagal tambah keranjang')";
			echo "</script>";
			header('Location: '.base_url().'add_do_stock');
		}
	}

	public function add_act_do_stock()
	{
		session_start();
		if ($_POST) {
			$_SESSION["no_do"] = $_POST['no_do'];
			$no_do = $_SESSION["no_do"];
			$tanggal_do = $_POST['tanggal_do'];
			$tujuan_do = $_POST['tujuan_do'];
			$nama_proyek = $_POST['text_proyek'];
			$alamat_do = $_POST['alamat_do'];
			$penerima_do = $_POST['penerima_do'];
			$no_telp_do = $_POST['no_telp_do'];

			$data_keranjang_do_stock = array('no_do' => $no_do,
			'tanggal_do' => $tanggal_do,
			'tujuan_do' => $tujuan_do,
			'nama_proyek' => $nama_proyek,
			'alamat_do' => $alamat_do,
			'penerima_do' => $penerima_do,
			'no_telp_do' => $no_telp_do );

			M_do_stock::addMaster($data_keranjang_do_stock);
			M_do_stock::copyTable('do_stock_keranjang', 'do_stock_order', $no_do);
			header('Location: ./add_do_stock');

		} else {
			echo "<script>";
			echo "alert('Gagal tambah keranjang')";
			echo "</script>";
			header('Location: '.base_url().'add_do_stock');
		}
	}
}
