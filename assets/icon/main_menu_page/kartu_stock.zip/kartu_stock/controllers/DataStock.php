<?php

/**
 * 
 */
class DataStock extends Controller
{
	public function index() {

		// login::ceklogin();
		session_start();

		if(isset($_GET['cari'])){
			$cari = $_GET['cari'];
			$_SESSION["cari"] = $cari;
		}

		$per_laman = 1;
		$_SESSION["per_laman"] = $per_laman;

		if(isset($_GET['per_laman'])) {
			$per_laman = $_GET['per_laman'];
			$_SESSION["per_laman"] = $per_laman;
		}

		$laman_sekarang = 1;
		if(isset($_GET['laman'])) {
			$laman_sekarang = $_GET['laman'];
			$laman_sekarang = ($laman_sekarang > 1) ? $laman_sekarang : 1;
		}

		if(isset($cari))
			$result = M_data_stock::get_search($cari);
		else
			$result = self::get('lpb');
		$total_data = count($result);
		$total_laman = ceil($total_data / $per_laman);
		$awal = ($laman_sekarang - 1) * $per_laman;
		if(isset($cari))			
			$data = self::searchUser($cari, $awal, $per_laman);
		else
			$data = self::get_limit('lpb', $awal, $per_laman);
		$laman = array('laman_sekarang' => $laman_sekarang, 'per_laman' => $per_laman );

		self::CreatePagging('data_stock', $data, $total_laman, $laman);
		// self::CreateView('data_user', $data);
	}

	public function getAdd() {
		// login::ceklogin();
		$data = self::get('lpb');
		self::CreateView('add_data_stock', $data);
	}

	public function add() {
		$data = array('lpb_nomor' => $_POST['lpb_nomor'],
					'lpb_date' => $_POST['lpb_date'],
					'lpb_proyek' => $_POST['lpb_proyek'],
					'lpb_lokasi' => $_POST['lpb_lokasi'],
					'lpb_nama_supplier' => $_POST['lpb_nama_supplier'],
					'lpb_material' => $_POST['lpb_material'],
					'lpb_section' => $_POST['lpb_section'],
					'lpb_warna' => $_POST['lpb_warna'],
					'lpb_ukuran' => $_POST['lpb_ukuran'],
					'lpb_vol' => $_POST['lpb_vol'],
					'lpb_sat' => $_POST['lpb_sat'] );
		M_data_stock::add($data);
		header('Location: '.base_url().'data_stock');
	}

	public function delete() {
		// login::ceklogin();
		$id = $_GET['id'];
		M_data_stock::delete($id);
		header('Location: '.base_url().'data_stock');
	}

	public function update() {
		// login::ceklogin();
		$id = $_GET['id'];
		$data = self::get_where('lpb', 'lpb_id', $id);
		self::CreateView('edit_data_stock', $data);
	}

	public function updateAction() {
		$id = $_POST['id'];
		$data = array('lpb_nomor' => $_POST['lpb_nomor'],
					'lpb_date' => $_POST['lpb_date'],
					'lpb_proyek' => $_POST['lpb_proyek'],
					'lpb_lokasi' => $_POST['lpb_lokasi'],
					'lpb_nama_supplier' => $_POST['lpb_nama_supplier'],
					'lpb_material' => $_POST['lpb_material'],
					'lpb_section' => $_POST['lpb_section'],
					'lpb_warna' => $_POST['lpb_warna'],
					'lpb_ukuran' => $_POST['lpb_ukuran'],
					'lpb_vol' => $_POST['lpb_vol'],
					'lpb_sat' => $_POST['lpb_sat'] );
		M_data_stock::update($id, $data);
		header('Location: '.base_url().'data_stock');
	}

	public function searchUser($cari, $awal, $per_laman) {
		$data = M_data_stock::get_search_limit($cari, $awal, $per_laman);
		return $data;
	}
}
?>