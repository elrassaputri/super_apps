<?php

/**
 * 
 */
class DataDoStock extends Controller
{
	public function index() {

		// login::ceklogin();
		session_start();

		if(isset($_GET['cari'])){
			$cari = $_GET['cari'];
			$_SESSION["cari"] = $cari;
		}

		$per_laman = 1;
		$_SESSION["per_laman"] = $per_laman;

		if(isset($_GET['per_laman'])) {
			$per_laman = $_GET['per_laman'];
			$_SESSION["per_laman"] = $per_laman;
		}

		$laman_sekarang = 1;
		if(isset($_GET['laman'])) {
			$laman_sekarang = $_GET['laman'];
			$laman_sekarang = ($laman_sekarang > 1) ? $laman_sekarang : 1;
		}

		if(isset($cari))
			$result = M_do_stock::get_search($cari);
		else
			$result = self::get('do_stock_master');
		$total_data = count($result);
		$total_laman = ceil($total_data / $per_laman);
		$awal = ($laman_sekarang - 1) * $per_laman;
		if(isset($cari))			
			$data = self::searchUser($cari, $awal, $per_laman);
		else
			$data = self::get_limit('do_stock_master', $awal, $per_laman);
		$laman = array('laman_sekarang' => $laman_sekarang, 'per_laman' => $per_laman );

		self::CreatePagging('data_do_stock', $data, $total_laman, $laman);
		// self::CreateView('data_user', $data);
	}

	public function getAdd() {
		// login::ceklogin();
		$data = self::get('do_stock_master');
		self::CreateView('add_data_do_stock', $data);
	}

	public function add() {
		$data = array('kode_do_stock_master' => $_POST['kode_do_stock_master'],
					'tanggal_do_stock' => $_POST['tanggal_do_stock'],
					'tujuan_do_stock' => $_POST['tujuan_do_stock'],
					'nama_proyek_do_stock' => $_POST['nama_proyek_do_stock'],
					'alamat_do_stock' => $_POST['alamat_do_stock'],
					'penerima_do_stock' => $_POST['penerima_do_stock'],
					'no_telp_do_stock' => $_POST['no_telp_do_stock'] );
		M_do_stock::add($data);
		header('Location: '.base_url().'data_do_stock');
	}

	public function delete() {
		// login::ceklogin();
		$id = $_GET['id'];
		M_do_stock::delete($id);
		header('Location: '.base_url().'data_do_stock');
	}

	public function update() {
		// login::ceklogin();
		$id = $_GET['id'];
		$data = self::get_where('do_stock_master', 'do_stock_master_id', $id);
		self::CreateView('edit_data_do_stock', $data);
	}

	public function updateAction() {
		$id = $_POST['id'];
		$data = array('kode_do_stock_master' => $_POST['kode_do_stock_master'],
					'tanggal_do_stock' => $_POST['tanggal_do_stock'],
					'tujuan_do_stock' => $_POST['tujuan_do_stock'],
					'nama_proyek_do_stock' => $_POST['nama_proyek_do_stock'],
					'alamat_do_stock' => $_POST['alamat_do_stock'],
					'penerima_do_stock' => $_POST['penerima_do_stock'],
					'no_telp_do_stock' => $_POST['no_telp_do_stock'] );
		M_do_stock::update($id, $data);
		header('Location: '.base_url().'data_do_stock');
	}

	public function searchUser($cari, $awal, $per_laman) {
		$data = M_do_stock::get_search_limit($cari, $awal, $per_laman);
		return $data;
	}
}
?>