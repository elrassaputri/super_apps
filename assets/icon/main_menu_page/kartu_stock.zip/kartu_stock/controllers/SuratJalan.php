<?php

/**
 * 
 */
class SuratJalan extends Controller
{

	public function add() {
		// login::ceklogin();
		if (isset($_GET['kode'])) {
			if ($_GET['kode'] != '') {
				$kode = $_GET['kode'];
				$data_material_do_stock = self::get_where('do_stock_order', 'kode_do_stock_master', $kode);
				$data_do_stock_master = self::get_where('do_stock_master', 'kode_do_stock_master', $kode);
				$data = array('do_stock_master' => $data_do_stock_master, 'do_stock_order' => $data_material_do_stock);
			}
		}else{
			$data_do_stock_master = self::get('do_stock_master');
			$data = array('do_stock_master' => $data_do_stock_master);
		}
		self::CreateView('add_surat_jalan', $data);
	}

	public function add_act_surat_jalan() {
		$no_surat = '';
		if ($no_surat == '') {
			$no_surat = self::no_surat();
		}

		$jml_material_order = $_POST['jml_material_order'];
		$data_update = array();
		$az=1;
		for ($ast=0; $ast < $jml_material_order; $ast++) { 
			$data_update['id'][$ast] = $_POST['vol_id_surat_jalan_'.$az];
			$data_update['id_lpb'][$ast] = $_POST['lpb_material_id_'.$az];
			$data_update['value'][$ast] = $_POST['vol_surat_jalan_kirim_'.$az];
			$data_update['kode_do_stock'][$ast] = $_POST['kode_do_stock_'.$az];
			$data_update['nama_material'][$ast] = $_POST['nama_material_'.$az];
			$az++;
		}

		$data_surat_jalan_master = array('kode_surat_jalan' => $no_surat,
					'tanggal' => $_POST['tanggal_do'],
					'tujuan' => $_POST['tujuan_do'],
					'nama_proyek' => $_POST['nama_proyek'],
					'alamat' => $_POST['alamat_do'],
					'penerima' => $_POST['penerima_do'],
					'no_telp' => $_POST['no_telp_do'],
					'kode_do_stock_master' => $_POST['no_do'] );
		$data_surat_jalan_material = array('kode_surat_jalan_master' => $no_surat, 'data_update' => $data_update);
		M_surat_jalan::add_master($data_surat_jalan_master);
		M_surat_jalan::add_material($data_surat_jalan_material);
		header('Location: '.base_url().'data_stock');
	}

	public function no_surat()
	{
		$chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
	    srand((double)microtime()*1000000);
	    $i = 0;
	    $pass = '' ;
	    while ($i <= 12) {
	    	$num = rand() % 33;
	        $tmp = substr($chars, $num, 1);
	        $pass = $pass . $tmp;
	        $i++;
	    }
	    return $pass;
	}

	public function delete() {
		// login::ceklogin();
		$id = $_GET['id'];
		M_data_stock::delete($id);
		header('Location: '.base_url().'data_stock');
	}

	public function update() {
		// login::ceklogin();
		$id = $_GET['id'];
		$data = self::get_where('lpb', 'lpb_id', $id);
		self::CreateView('edit_data_stock', $data);
	}

	public function updateAction() {
		$id = $_POST['id'];
		$data = array('lpb_nomor' => $_POST['lpb_nomor'],
					'lpb_date' => $_POST['lpb_date'],
					'lpb_proyek' => $_POST['lpb_proyek'],
					'lpb_lokasi' => $_POST['lpb_lokasi'],
					'lpb_nama_supplier' => $_POST['lpb_nama_supplier'],
					'lpb_material' => $_POST['lpb_material'],
					'lpb_section' => $_POST['lpb_section'],
					'lpb_warna' => $_POST['lpb_warna'],
					'lpb_ukuran' => $_POST['lpb_ukuran'],
					'lpb_vol' => $_POST['lpb_vol'],
					'lpb_sat' => $_POST['lpb_sat'] );
		M_data_stock::update($id, $data);
		header('Location: '.base_url().'data_stock');
	}
}
?>