<?php

/**
 * 
 */
class RekapStock extends Controller
{
	public function index() {

		// login::ceklogin();
		session_start();

		if(isset($_GET['cari'])){
			$cari = $_GET['cari'];
			$_SESSION["cari"] = $cari;
		}

		$per_laman = 1;
		$_SESSION["per_laman"] = $per_laman;

		if(isset($_GET['per_laman'])) {
			$per_laman = $_GET['per_laman'];
			$_SESSION["per_laman"] = $per_laman;
		}

		$laman_sekarang = 1;
		if(isset($_GET['laman'])) {
			$laman_sekarang = $_GET['laman'];
			$laman_sekarang = ($laman_sekarang > 1) ? $laman_sekarang : 1;
		}

		if(isset($cari))
			$result = M_rekap_stock::get_search($cari);
		else
			$result = self::get('rekap_stock');
		$total_data = count($result);
		$total_laman = ceil($total_data / $per_laman);
		$awal = ($laman_sekarang - 1) * $per_laman;
		if(isset($cari))
			$data = self::searchUser($cari, $awal, $per_laman);
		else
			$data = self::get_limit('rekap_stock', $awal, $per_laman);
		$laman = array('laman_sekarang' => $laman_sekarang, 'per_laman' => $per_laman );

		self::CreatePagging('rekap_stock', $data, $total_laman, $laman);
		// self::CreateView('data_user', $data);
	}

	public function getAdd() {
		// login::ceklogin();
		$supliers = self::get('supliers');
		$lokasi = self::get('lokasi_stok');
		$data = array('supliers' => $supliers, 'lokasi' => $lokasi );
		self::CreateView('add_rekap_stock', $data);
	}

	public function add() {
		$data = array('section' => $_POST['section'],
					'deskripsi' => $_POST['deskripsi'],
					'warna' => $_POST['warna'],
					'ukuran' => $_POST['ukuran'],
					'masuk' => $_POST['masuk'],
					'keluar' => $_POST['keluar'],
					'saldo' => $_POST['saldo'],
					'lokasi_rak' => $_POST['lokasi_rak'],
					'berat' => $_POST['berat'] );
		M_rekap_stock::add($data);
		header('Location: '.base_url().'rekap');
	}

	public function delete() {
		// login::ceklogin();
		$id = $_GET['id'];
		M_rekap_stock::delete($id);
		header('Location: '.base_url().'rekap');
	}

	public function update() {
		// login::ceklogin();
		$id = $_GET['id'];
		$data = self::get_where('rekap_stock', 'id', $id);
		self::CreateView('edit_rekap_stock', $data);
	}

	public function updateAction() {
		$id = $_POST['id'];
		$data = array('section' => $_POST['section'],
					'deskripsi' => $_POST['deskripsi'],
					'warna' => $_POST['warna'],
					'ukuran' => $_POST['ukuran'],
					'masuk' => $_POST['masuk'],
					'keluar' => $_POST['keluar'],
					'saldo' => $_POST['saldo'],
					'lokasi_rak' => $_POST['lokasi_rak'],
					'berat' => $_POST['berat'] );
		M_rekap_stock::update($id, $data);
		header('Location: '.base_url().'rekap');
	}

	public function searchUser($cari, $awal, $per_laman) {
		$data = M_rekap_stock::get_search_limit($cari, $awal, $per_laman);
		return $data;
	}

	public function ExportRekapStock()
	{
		$result = self::get('rekap_stock');
		self::CreateView('export_rekap_stock', $result);
	}

	public function PrintRekapStock()
	{
		$result = self::get('rekap_stock');
		self::CreateView('print_rekap_stock', $result);
	}
}
?>