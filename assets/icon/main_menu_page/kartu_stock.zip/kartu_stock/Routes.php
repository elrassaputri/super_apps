<?php

//Home Kartu Stock
Route::set('kartu_stock', function(){
	KartuStock::index();
});
//Tambah kartu stock
Route::set('add_kartu_stock', function(){
	KartuStock::getAdd();
});
//Tambah action kartu stock
Route::set('add_act_kartu_stock', function(){
	KartuStock::add();
});
//Edit Kartu Stock
Route::set('edit_kartu_stock', function(){
	KartuStock::update();
});
//Edit Action Kartu Stock
Route::set('edit_act_kartu_stock', function(){
	KartuStock::updateAction();
});
//Hapus Kartu Stock
Route::set('hapus_kartu_stock', function(){
	KartuStock::delete();
});

// Home Rekap Stock
Route::set('rekap_stock', function(){
	RekapStock::index();
});
//Tambah rekap stock
Route::set('add_rekap_stock', function(){
	RekapStock::getAdd();
});
//Tambah action rekap stock
Route::set('add_act_rekap_stock', function(){
	RekapStock::add();
});
//Edit rekap Stock
Route::set('edit_rekap_stock', function(){
	RekapStock::update();
});
//Edit Action rekap Stock
Route::set('edit_act_rekap_stock', function(){
	RekapStock::updateAction();
});
//Hapus reakap Stock
Route::set('hapus_rekap_stock', function(){
	RekapStock::delete();
});
//export reakap Stock
Route::set('export_rekap_stock', function(){
	RekapStock::ExportRekapStock();
});
//export reakap Stock
Route::set('print_rekap_stock', function(){
	RekapStock::PrintRekapStock();
});

//Home Data Stock
Route::set('data_stock', function(){
	DataStock::index();
});
//Tambah Data stock
Route::set('add_data_stock', function(){
	DataStock::getAdd();
});
//Tambah action data stock
Route::set('add_act_data_stock', function(){
	DataStock::add();
});
//Edit data Stock
Route::set('edit_data_stock', function(){
	DataStock::update();
});
//Edit Action data Stock
Route::set('edit_act_data_stock', function(){
	DataStock::updateAction();
});
//Hapus data Stock
Route::set('hapus_data_stock', function(){
	DataStock::delete();
});

//add do stock
Route::set('add_do_stock', function(){
	DoStock::add();
});
//add keranjang do stock
Route::set('add_keranjang_do_stock', function(){
	DoStock::addKeranjang();
});
//delete keranjang do stock
Route::set('delete_keranjang_do_stock', function(){
	DoStock::deleteKeranjang();
});
//add do stock
Route::set('add_act_do_stock', function(){
	DoStock::add_act_do_stock();
});

//add surat jalan
Route::set('add_surat_jalan', function(){
	SuratJalan::add();
});
//add surat jalan
Route::set('add_act_surat_jalan', function(){
	SuratJalan::add_act_surat_jalan();
});

//Home Data Stock
Route::set('data_do_stock', function(){
	DataDoStock::index();
});
/*
//Tambah Data stock
Route::set('add_data_do_stock', function(){
	DataStock::getAdd();
});
//Tambah action data stock
Route::set('add_act_data_do_stock', function(){
	DataStock::add();
});
*/
//Edit data Stock
Route::set('edit_data_do_stock', function(){
	DataDoStock::update();
});
//Edit Action data Stock
Route::set('edit_act_data_do_stock', function(){
	DataDoStock::updateAction();
});
//Hapus data Stock
Route::set('hapus_data_do_stock', function(){
	DataDoStock::delete();
});

//Home Data Stock
Route::set('data_surat_jalan', function(){
	DataSuratJalan::index();
});
/*
//Tambah Data stock
Route::set('add_data_surat_jalan', function(){
	DataStock::getAdd();
});
//Tambah action data stock
Route::set('add_act_data_surat_jalan', function(){
	DataStock::add();
});
*/
//Edit data Stock
Route::set('edit_data_surat_jalan', function(){
	DataSuratJalan::update();
});
//Edit Action data Stock
Route::set('edit_act_data_surat_jalan', function(){
	DataSuratJalan::updateAction();
});
//Hapus data Stock
Route::set('hapus_data_surat_jalan', function(){
	DataSuratJalan::delete();
});

?>