<!DOCTYPE html>
<html>
<head>
    <?php require_once './template/metafile.php' ?>
    <title>Srimurni Admin</title>
    <?php require_once './template/metacss.php' ?>
</head>
<body>
    <script type="text/javascript">
        $(document).ready(function () {
            $(function () {
                $(".chzn-select").chosen();

            });
        });
    </script>
    <div id="container">

        <?php include 'template/header.php'; ?>

        <div id="content-wraps">        

            <?php include 'template/secondary_bar.php'; ?>

            <?php include 'template/aside_bar.php'; ?>

            <section id="main" class="column">

                <h4 class="alert_info">Selamat Datang <strong>PT. Srimurni Surabaya</strong>  </h4> 

                <article class="module width_full">

                    <div class="module_content">
                        <main>
                            <article>
                                <section>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-8 offset-md-2 mt-5">

                                                <a href="<?php echo base_url() ?>rekap">
                                                    <button class="btn btn-flat btn-danger mb-3">Kembali</button>
                                                </a>

                                                <?php if (isset($_GET['success'])) {
                                                    if ($_GET['success'] == '1') { ?>
                                                        <div class="alert alert-success text-center">Data berhasil ditambahkan</div>
                                                    <?php } else { ?>
                                                        <div class="alert alert-danger text-center">Data gagal ditambahkan</div>
                                                    <?php } ?>
                                                <?php } ?>

                                                <?php $no=0; foreach ($data as $value): ?>
                                                <form action="<?php echo base_url()?>edit_act_rekap_stock" method="post">
                                                 <input type="hidden" name="id" value="<?php echo $value['id'] ?>">
                                                 <div class="form-group">
                                                    <input type="text" name="section" id="section" class="form-control" value="<?php echo $value['section'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="deskripsi" id="deskripsi" class="form-control" value="<?php echo $value['deskripsi'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="warna" id="warna" class="form-control" value="<?php echo $value['warna'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="ukuran" id="ukuran" class="form-control" value="<?php echo $value['ukuran'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Quantity</label>
                                                    <hr>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="masuk" id="masuk" class="form-control" onchange="masukChange(this.value)" value="<?php echo $value['masuk'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="keluar" id="keluar" class="form-control" onchange="keluarChange(this.value)" value="<?php echo $value['keluar'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="saldo" id="saldo" readonly="readonly" class="form-control" value="<?php echo $value['saldo'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lokasi_rak" id="lokasi_rak" class="form-control" value="<?php echo $value['lokasi_rak'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="berat" id="berat" class="form-control" value="<?php echo $value['berat'] ?>">
                                                </div>

                                                <div class="form-group">
                                                    <button type="submit" name="submit" value="submit" class="btn btn-flat btn-success w-100">Edit</button>
                                                </div>
                                            </form>
                                        <?php endforeach ?>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </article>
                </main>

                <div class="clear"></div>
            </div>
        </article> <!-- end of stats article -->
    </div> 

    <div class="clear"></div>

    <div class="spacer"></div>


</section>
</div>
</div>

<?php require_once './template/metajs.php' ?>
<script type="text/javascript">
    function masukChange(val) {
        var val_keluar = document.getElementById("keluar").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val - val_keluar;
        saldo.setAttribute('value', val_saldo);
    }
    function keluarChange(val) {
        var val_masuk = document.getElementById("masuk").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val_masuk - val;
        saldo.setAttribute('value', val_saldo);
    }
</script>
</body>
</html>