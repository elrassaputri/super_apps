<!DOCTYPE html>
<html>
<head>
    <?php require_once './template/metafile.php' ?>
    <title>Srimurni Admin</title>
    <?php require_once './template/metacss.php' ?>
</head>
<body>
    <script type="text/javascript">
        $(document).ready(function () {
            $(function () {
                $(".chzn-select").chosen();

            });
        });
    </script>
    <div id="container">

        <?php include 'template/header.php'; ?>

        <div id="content-wraps">        

            <?php include 'template/secondary_bar.php'; ?>

            <?php include 'template/aside_bar.php'; ?>

            <section id="main" class="column">

                <h4 class="alert_info">Selamat Datang <strong>PT. Srimurni Surabaya</strong>  </h4> 

                <article class="module width_full">

                    <div class="module_content">
                        <main>
                            <article>
                                <section>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12 mt-5">

                                                <a href="<?php echo base_url() ?>data_stock">
                                                    <button class="btn btn-flat btn-danger mb-3">Kembali</button>
                                                </a>

                                                <?php if (isset($_GET['success'])) {
                                                    if ($_GET['success'] == '1') { ?>
                                                        <div class="alert alert-success text-center">Data berhasil ditambahkan</div>
                                                    <?php } else { ?>
                                                        <div class="alert alert-danger text-center">Data gagal ditambahkan</div>
                                                    <?php } ?>
                                                <?php } ?>

                                                <form action="<?php echo base_url()?>add_act_surat_jalan" method="post">
                                                    <?php if (isset($data['do_stock_order'])) {
                                                        foreach ($data['do_stock_master'] as $key => $value) { ?>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <select name="no_do" id="no_do" class="form-control" onchange="idChange(this.value)">
                                                                            <option>Pilih No.DO</option>
                                                                            <?php foreach ($data['do_stock_master'] as $key_kode => $value_kode) { ?>
                                                                                <option value="<?php echo $value_kode['kode_do_stock_master'] ?>" <?php if (isset($_GET['kode'])) {
                                                                                    if ($value_kode['kode_do_stock_master'] == $_GET['kode']) {
                                                                                        echo "selected";
                                                                                    }
                                                                                } ?>><?php echo $value_kode['kode_do_stock_master'] ?></option>
                                                                            <?php } ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <input type="date" name="tanggal_do" id="tanggal_do" class="form-control" readonly="readonly" value="<?php echo $value['tanggal_do_stock'] ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <input type="text" name="tujuan_do" id="tujuan_do"    class="form-control" value="<?php echo $value['tujuan_do_stock'] ?>" readonly="readonly">
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <input type="text" name="nama_proyek" id="nama_proyek" class="form-control" readonly="readonly" value="<?php echo $value['nama_proyek_do_stock'] ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <input type="text" name="alamat_do" id="alamat_do" class="form-control" readonly="readonly" value="<?php echo $value['alamat_do_stock'] ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <input type="text" name="penerima_do" id="penerima_do"    class="form-control" readonly="readonly" value="<?php echo $value['penerima_do_stock'] ?>">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <input type="text" name="no_telp_do" id="no_telp_do"    class="form-control" readonly="readonly" value="<?php echo $value['no_telp_do_stock'] ?>">
                                                                    </div>                                                          
                                                                </div>
                                                            </div>
                                                        <?php }
                                                    }else{ ?>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <select name="no_do" id="no_do" class="form-control" onchange="idChange(this.value)">
                                                                    <option>Pilih No.DO</option>
                                                                    <?php foreach ($data['do_stock_master'] as $key_kode => $value_kode) { ?>
                                                                        <option value="<?php echo $value_kode['kode_do_stock_master'] ?>"><?php echo $value_kode['kode_do_stock_master'] ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="date" name="tanggal_do" id="tanggal_do" class="form-control" readonly="readonly">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" name="tujuan_do" id="tujuan_do"    class="form-control" readonly="readonly" placeholder="Dikirim ke">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <input type="text" name="nama_proyek" id="nama_proyek" class="form-control" readonly="readonly" placeholder="Nama Proyek">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" name="alamat_do" id="alamat_do" class="form-control" readonly="readonly" placeholder="Alamat">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" name="penerima_do" id="penerima_do"    class="form-control" readonly="readonly" placeholder="Penerima">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" name="no_telp_do" id="no_telp_do"    class="form-control" readonly="readonly" placeholder="No Telp">
                                                            </div>                                                          
                                                        </div>
                                                    </div>
                                                    <?php } ?>

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <h4>Keranjang DO Material</h4>
                                                            <hr>
                                                        </div>
                                                        <div class="form-group">
                                                            <table class="table table-hover table-bordered table-responsive">
                                                                <caption class="ml-3">List Material</caption>
                                                                <thead class="thead-light text-center">
                                                                    <tr>
                                                                        <th scope="col">No</th>
                                                                        <th scope="col">Jenis Pekerjaan</th>
                                                                        <th scope="col">Kode</th>
                                                                        <th scope="col">Panjang</th>
                                                                        <th scope="col">Finish</th>
                                                                        <th scope="col">Budget</th>
                                                                        <th scope="col">Volume</th>
                                                                        <th scope="col">Type</th>
                                                                        <th scope="col">Ket</th>
                                                                        <th scope="col">Stock Dikirim</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $no=0; if (isset($data['do_stock_order'])) {
                                                                    foreach ($data['do_stock_order'] as $key => $value) { ?>
                                                                        <tr>
                                                                            <td><?php echo ++$no ?></td>
                                                                            <td><?php echo $value['nama_material'] ?></td>
                                                                            <td><?php echo $value['kode_do_stock'] ?></td>
                                                                            <td><?php echo $value['pjg_do_stock'] ?></td>
                                                                            <td><?php echo $value['finish_do_stock'] ?></td>
                                                                            <td><?php echo $value['budget_do_stock'] ?></td>
                                                                            <td><?php echo $value['vol_do_stock'] ?></td>
                                                                            <td><?php echo $value['type_do_stock'] ?></td>
                                                                            <td><?php echo $value['ket_do_stock'] ?></td>
                                                                            <td>
                                                                                <input type="hidden" name="kode_do_stock_<?php echo $no ?>" id="kode_do_stock" value="<?php echo $value['lpb_material_id'] ?>">

                                                                                <input type="hidden" name="nama_material_<?php echo $no ?>" id="nama_material" value="<?php echo $value['nama_material'] ?>">

                                                                                <input type="text" name="vol_surat_jalan_kirim_<?php echo $no ?>" id="vol_surat_jalan_kirim" value="<?php echo $value['vol_do_stock'] ?>">

                                                                                <input type="hidden" name="vol_id_surat_jalan_<?php echo $no ?>" id="vol_id_surat_jalan" value="<?php echo $value['do_stock_order_id'] ?>">

                                                                                <input type="hidden" name="lpb_material_id_<?php echo $no ?>" id="lpb_material_id" value="<?php echo $value['lpb_material_id'] ?>">

                                                                                <input type="hidden" name="jml_material_order" value="<?php echo $no ?>">
                                                                            </td>
                                                                        </tr>
                                                                    <?php }} ?>
                                                                </tbody>
                                                            </table>
                                                        </div>                                                          
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <button type="submit" name="submit" value="submit" class="btn btn-flat btn-success w-100">Buat Surat Jalan</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </article>
                        </main>

                        <div class="clear"></div>
                    </div>
                </article> <!-- end of stats article -->
            </div> 

            <div class="clear"></div>

            <div class="spacer"></div>


        </section>
    </div>
</div>

<?php require_once './template/metajs.php' ?>
<script>
  var base_url = "http://localhost/pos11/Admin/kartu_stock/";

  function idChange(val) {
    window.location.href = base_url + 'add_surat_jalan?kode=' + val;
    document.getElementById("demo").innerHTML = "You selected: " + val;
  }
  function jmlChange(val) {
    var hb = document.getElementById("harga_barang").value;
    var st = document.getElementById("subtotal");
    var sb = document.getElementById("stock_barang");
    var sh_v = document.getElementById("stock_hidden").value;
    var total = hb * val;
    var sb_n = sh_v - val;
    st.setAttribute('value', total);
    sb.setAttribute('value', sb_n);
  }
  function bayarOnchange(val) {
    var tb = document.getElementById("total_belanja").value;
    var kembali = document.getElementById("kembalian");
    kembalian.setAttribute('value', val - tb);
  }
  function addTransaksi() {
    window.location.href = 'http://localhost/distro-meup/Transaksi/AddTransaksi';
  }
</script>
</body>
</html>