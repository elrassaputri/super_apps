<!DOCTYPE html>
<html>
<head>
    <?php require_once './template/metafile.php' ?>
    <title>Srimurni Admin</title>
    <?php require_once './template/metacss.php' ?>
</head>
<body>
    <script type="text/javascript">
        $(document).ready(function () {
            $(function () {
                $(".chzn-select").chosen();

            });
        });
    </script>
    <div id="container">

        <?php include 'template/header.php'; ?>

        <div id="content-wraps">        

            <?php include 'template/secondary_bar.php'; ?>

            <?php include 'template/aside_bar.php'; ?>

            <section id="main" class="column">

                <h4 class="alert_info">Selamat Datang <strong>PT. Srimurni Surabaya</strong>  </h4> 

                <article class="module width_full">

                    <div class="module_content">
                        <main>
                            <article>
                                <section>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-8 offset-md-2 mt-5">

                                                <a href="<?php echo base_url() ?>data_stock">
                                                    <button class="btn btn-flat btn-danger mb-3">Kembali</button>
                                                </a>

                                                <?php if (isset($_GET['success'])) {
                                                    if ($_GET['success'] == '1') { ?>
                                                        <div class="alert alert-success text-center">Data berhasil ditambahkan</div>
                                                    <?php } else { ?>
                                                        <div class="alert alert-danger text-center">Data gagal ditambahkan</div>
                                                    <?php } ?>
                                                <?php } ?>

                                                <?php $no=0; foreach ($data as $value): ?>
                                                <form action="<?php echo base_url()?>edit_act_data_stock" method="post">
                                                 <input type="hidden" name="id" value="<?php echo $value['lpb_id'] ?>">
                                                 <div class="form-group">
                                                    <input type="text" name="lpb_nomor" id="lpb_nomor" class="form-control" value="<?php echo $value['lpb_nomor'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="date" name="lpb_date" id="lpb_date" class="form-control" value="<?php echo $value['lpb_date'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_proyek" id="lpb_proyek" class="form-control" value="<?php echo $value['lpb_proyek'] ?>">
                                                </div>
                                                <div class="form-group">
                                                	<textarea name="lpb_lokasi" id="lpb_lokasi" class="form-control"><?php echo $value['lpb_lokasi'] ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_nama_supplier" id="lpb_nama_supplier" class="form-control" value="<?php echo $value['lpb_nama_supplier'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_material" id="lpb_material" class="form-control" value="<?php echo $value['lpb_material'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_section" id="lpb_section" class="form-control" value="<?php echo $value['lpb_section'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_warna" id="lpb_warna" class="form-control" value="<?php echo $value['lpb_warna'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_ukuran" id="lpb_ukuran" class="form-control" value="<?php echo $value['lpb_ukuran_1'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_vol" id="lpb_vol" class="form-control" value="<?php echo $value['lpb_vol'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="lpb_sat" id="lpb_sat" class="form-control" value="<?php echo $value['lpb_sat'] ?>">
                                                </div>

                                                <div class="form-group">
                                                    <button type="submit" name="submit" value="submit" class="btn btn-flat btn-success w-100">Edit</button>
                                                </div>
                                            </form>
                                        <?php endforeach ?>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </article>
                </main>

                <div class="clear"></div>
            </div>
        </article> <!-- end of stats article -->
    </div> 

    <div class="clear"></div>

    <div class="spacer"></div>


</section>
</div>
</div>

<?php require_once './template/metajs.php' ?>
<script type="text/javascript">
    function masukChange(val) {
        var val_keluar = document.getElementById("keluar").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val - val_keluar;
        saldo.setAttribute('value', val_saldo);
    }
    function keluarChange(val) {
        var val_masuk = document.getElementById("masuk").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val_masuk - val;
        saldo.setAttribute('value', val_saldo);
    }
</script>
</body>
</html>