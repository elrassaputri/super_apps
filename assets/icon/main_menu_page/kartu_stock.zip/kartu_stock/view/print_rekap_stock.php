<!DOCTYPE html>
<html>
<head>
	<?php require_once './template/metafile.php' ?>
	<title>Srimurni Admin</title>
	<?php require_once './template/metacss.php' ?>
</head>
<body>

<table border="1" style="width: 100%">
	<tr>
		<th rowspan="2">No</th>
		<th rowspan="2">Section</th>
		<th rowspan="2">Deskripsi</th>
		<th rowspan="2">Warna</th>
		<th rowspan="2">Ukuran (mm)</th>
		<th colspan="3">Quantity (btg)</th>
		<th rowspan="2">Lokasi Rak / Ket</th>
		<th rowspan="2">Berat KG/M</th>
	</tr>
	<tr>
		<th>Masuk</th>
		<th>Keluar</th>
		<th>Saldo</th>
	</tr>
	<?php 
	$no = 1;
	foreach ($data as $value) {?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $value['section'] ?></td>
			<td><?php echo $value['deskripsi'] ?></td>
			<td><?php echo $value['warna'] ?></td>
			<td><?php echo $value['ukuran'] ?></td>
			<td><?php echo $value['masuk'] ?></td>
			<td><?php echo $value['keluar'] ?></td>
			<td><?php echo $value['saldo'] ?></td>
			<td><?php echo $value['lokasi_rak'] ?></td>
			<td><?php echo $value['berat'] ?></td>
		</tr>
	<?php } ?>
</table>

<?php require_once './template/metajs.php' ?>
<script>
	window.print();
</script>
</body>
</html>