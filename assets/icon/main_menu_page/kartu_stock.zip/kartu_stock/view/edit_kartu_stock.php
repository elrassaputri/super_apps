<!DOCTYPE html>
<html>
<head>
    <?php require_once './template/metafile.php' ?>
    <title>Srimurni Admin</title>
    <?php require_once './template/metacss.php' ?>
</head>
<body>
    <script type="text/javascript">
        $(document).ready(function () {
            $(function () {
                $(".chzn-select").chosen();

            });
        });
    </script>
    <div id="container">

        <?php include 'template/header.php'; ?>

        <div id="content-wraps">        

            <?php include 'template/secondary_bar.php'; ?>

            <?php include 'template/aside_bar.php'; ?>

            <section id="main" class="column">

                <h4 class="alert_info">Selamat Datang <strong>PT. Srimurni Surabaya</strong>  </h4> 

                <article class="module width_full">

                    <div class="module_content">
                        <main>
                            <article>
                                <section>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-8 offset-md-2 mt-5">

                                                <a href="<?php echo base_url() ?>kartu_stock">
                                                    <button class="btn btn-flat btn-danger mb-3">Kembali</button>
                                                </a>

                                                <?php if (isset($_GET['success'])) {
                                                    if ($_GET['success'] == '1') { ?>
                                                        <div class="alert alert-success text-center">Data berhasil ditambahkan</div>
                                                    <?php } else { ?>
                                                        <div class="alert alert-danger text-center">Data gagal ditambahkan</div>
                                                    <?php } ?>
                                                <?php } ?>

                                                <?php $no=0; foreach ($data as $value): ?>
                                                <form action="<?php echo base_url()?>edit_act_kartu_stock" method="post">
                                                 <input type="hidden" name="id" value="<?php echo $value['id'] ?>">
                                                 <div class="form-group">
                                                    <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo $value['tanggal'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="no_sj" id="no_sj" class="form-control" value="<?php echo $value['no_sj'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="no_lpb" id="no_lpb" class="form-control" value="<?php echo $value['no_lpb'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <select name="nama_supplier" id="nama_supplier" class="form-control">
                                                        <option>Nama Supplier</option>
                                                        <?php foreach ($listdata['supliers'] as $listkey_supliers => $listvalue_supliers) { ?>
                                                            <option value="<?php echo $listvalue_supliers['suplier_name'] ?>" <?php if ($listvalue_supliers['suplier_name'] === $value['nama_supplier']) echo "selected"; ?>><?php echo $listvalue_supliers['suplier_name'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <select name="lokasi" id="lokasi" class="form-control">
                                                        <option>Lokasi</option>
                                                        <?php foreach ($listdata['lokasi'] as $listkey_lokasi => $listvalue_lokasi) { ?>
                                                            <option value="<?php echo $listvalue_lokasi['lokasi'] ?>" <?php if ($listvalue_lokasi['lokasi'] === $value['lokasi']) echo "selected"; ?>><?php echo $listvalue_lokasi['lokasi'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Quantity</label>
                                                    <hr>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="masuk" id="masuk" class="form-control" onchange="masukChange(this.value)" value="<?php echo $value['masuk'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="keluar" id="keluar" class="form-control" onchange="keluarChange(this.value)" value="<?php echo $value['keluar'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="saldo" id="saldo" readonly="readonly" class="form-control" value="<?php echo $value['saldo'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Sisa Proses</label>
                                                    <hr>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="pjg" id="pjg" class="form-control" value="<?php echo $value['pjg'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="qty" id="qty" class="form-control" value="<?php echo $value['qty'] ?>">
                                                </div>
                                                <div class="form-group">
                                                    <textarea name="ket" class="form-control" rows="5" cols="25"><?php echo $value['ket']; ?></textarea>
                                                </div>

                                                <div class="form-group">
                                                    <button type="submit" name="submit" value="submit" class="btn btn-flat btn-success w-100">Edit</button>
                                                </div>
                                            </form>
                                        <?php endforeach ?>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </article>
                </main>

                <div class="clear"></div>
            </div>
        </article> <!-- end of stats article -->
    </div> 

    <div class="clear"></div>

    <div class="spacer"></div>


</section>
</div>
</div>

<?php require_once './template/metajs.php' ?>
<script type="text/javascript">
    function masukChange(val) {
        var val_keluar = document.getElementById("keluar").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val - val_keluar;
        saldo.setAttribute('value', val_saldo);
    }
    function keluarChange(val) {
        var val_masuk = document.getElementById("masuk").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val_masuk - val;
        saldo.setAttribute('value', val_saldo);
    }
</script>
</body>
</html>