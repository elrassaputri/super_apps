<!DOCTYPE html>
<html>
<head>
	<?php require_once './template/metafile.php' ?>
	<title>Srimurni Admin</title>
	<?php require_once './template/metacss.php' ?>
</head>
<body>
	<script type="text/javascript">
		$(document).ready(function () {
			$(function () {
				$(".chzn-select").chosen();

			});
		});
	</script>
	<div id="container">

		<?php include 'template/header.php'; ?>

		<div id="content-wraps">		
			
			<?php include 'template/secondary_bar.php'; ?>

			<?php include 'template/aside_bar.php'; ?>

			<section id="main" class="column">

				<h4 class="alert_info">Selamat Datang <strong>PT. Srimurni Surabaya</strong>  </h4> 

				<article class="module width_full">

					<div class="module_content">


						<main>
							<article>
								<section>
									<div class="container">
										<div class="row">
											<div class="col-12">
												<h2 class="my-5 text-center">data Stock</h2>
												<div class="row justify-content-between align-items-end mb-4">
													<div class="col-3">
														<span>Tampilkan</span>
														<span>:</span>
														<form action="<?php echo base_url() ?>data_stock" method="GET">
															<input type="hidden" name="laman" value="<?php if(isset($_GET["laman"])) echo $_GET["laman"] ?>">
															<select name="per_laman" class="form-control w-50" onchange='this.form.submit()'>
																<option value="1" <?php if ($_SESSION["per_laman"] == 1) echo "selected"; ?>>1</option>
																<option value="2" <?php if ($_SESSION["per_laman"] == 2) echo "selected"; ?>>2</option>
																<option value="3" <?php if ($_SESSION["per_laman"] == 3) echo "selected"; ?>>3</option>
															</select>
															<input type="hidden" name="cari" value="<?php if(isset($_SESSION["cari"])) echo $_SESSION["cari"] ?>">
														</form>
													</div>
													<form action="<?php echo base_url() ?>data_stock" method="GET" class="col-6">
														<div class="d-flex">
															<input type="text" name="cari" placeholder="Cari data alumni" class="form-control">
															<button class="btn btn-flat font-weight-bold text-muted ml-2" type="submit">Cari</button>
														</form>
													</div>

													<div class="col-3 d-flex justify-content-end">
														<a href="<?php echo base_url() ?>add_data_stock">
															<button class="btn btn-flat btn-success">Tambah</button>
														</a>
													</div>
												</div>

												<table class="table table-hover table-bordered table-responsive">
													<caption class="ml-3">data Stock</caption>
													<thead class="thead-light text-center">
														<tr>
															<th scope="col">No</th>
															<th scope="col">No.LPB</th>
															<th scope="col">Tanggal</th>
															<th scope="col">Proyek</th>
															<th scope="col">Lokasi</th>
															<th scope="col">Supplier</th>
															<th scope="col">Nama Material</th>
															<th scope="col">Section</th>
															<th scope="col">Warna</th>
															<th scope="col">Ukuran</th>
															<th scope="col">Stok Masuk</th>
															<th scope="col">Satuan</th>
															<th scope="col">Action</th>
														</tr>
													</thead>
													<tbody>
														<?php $no = ($laman['laman_sekarang'] * $laman['per_laman']) - ($laman['per_laman'] - 1);
														foreach ($data as $value): ?>
															<tr>
																<td><?php echo $no ?></td>
																<td><?php echo $value['lpb_nomor'] ?></td>
																<td><?php echo $value['lpb_date'] ?></td>
																<td><?php echo $value['lpb_proyek'] ?></td>
																<td><?php echo $value['lpb_lokasi'] ?></td>
																<td><?php echo $value['lpb_nama_supplier'] ?></td>
																<td><?php echo $value['lpb_material'] ?></td>
																<td><?php echo $value['lpb_section'] ?></td>
																<td><?php echo $value['lpb_warna'] ?></td>
																<td><?php echo $value['lpb_ukuran_1'] ?></td>
																<td><?php echo $value['lpb_vol'] ?></td>
																<td><?php echo $value['lpb_sat'] ?></td>
																<td>
																	<a href="<?php echo base_url() ?>edit_data_stock?id=<?php echo $value['lpb_id'] ?>">
																		<button class="btn btn-flat btn-warning text-white">Edit</button>
																	</a>

																	<a href="<?php echo base_url() ?>hapus_data_stock?id=<?php echo $value['lpb_id'] ?>">
																		<button class="btn btn-flat btn-danger">Hapus</button>
																	</a>

																	<a href="<?php echo base_url() ?>add_do_stock?id=<?php echo $value['lpb_id'] ?>">
																		<button class="btn btn-flat btn-primary">DO Stock</button>
																	</a>

																	<a href="<?php echo base_url() ?>add_surat_jalan?id=<?php echo $value['lpb_id'] ?>">
																		<button class="btn btn-flat btn-info">Surat Jalan</button>
																	</a>
																</td>
															</tr>
															<?php $no++; ?>
														<?php endforeach ?>
													</tbody>
												</table>

												<div class="flex flex-spaceBetween">

													<div class="pagging">
														<?php
														if($total_laman > 1) {
															if($laman['laman_sekarang'] > 1) { ?>
																<a href="<?php echo base_url() ?>data_stock?laman=<?php echo $laman['laman_sekarang'] - 1 ?><?php if(isset($_GET['per_laman'])) echo '&per_laman='.$_GET['per_laman'] ?><?php if(isset($_SESSION["cari"])) echo '&cari='.$_SESSION["cari"] ?>" class="text-dark">Sebelumnya</a>
															<?php } else { ?>
																Sebelumnya
															<?php }

															if($laman['laman_sekarang'] < $total_laman) { ?>
																<a href="<?php echo base_url() ?>data_stock?laman=<?php echo $laman['laman_sekarang'] + 1 ?><?php if(isset($_GET['per_laman'])) echo '&per_laman='.$_GET['per_laman'] ?><?php if(isset($_SESSION["cari"])) echo '&cari='.$_SESSION["cari"] ?>" class="text-dark ml-2">Selanjutnya</a>
															<?php } else { ?>
																Selanjutnya
															<?php }
														}
														?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</section>
							</article>
						</main>



						<div class="clear"></div>
					</div>
				</article> <!-- end of stats article -->
			</div> 

			<div class="clear"></div>

			<div class="spacer"></div>


		</section>
	</div>
</div>

<?php require_once './template/metajs.php' ?>
</body>
</html>