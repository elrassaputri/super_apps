<!DOCTYPE html>
<html>
<head>
    <?php require_once './template/metafile.php' ?>
    <title>Srimurni Admin</title>
    <?php require_once './template/metacss.php' ?>
</head>
<body>
    <script type="text/javascript">
        $(document).ready(function () {
            $(function () {
                $(".chzn-select").chosen();

            });
        });
    </script>
    <div id="container">

        <?php include 'template/header.php'; ?>

        <div id="content-wraps">        

            <?php include 'template/secondary_bar.php'; ?>

            <?php include 'template/aside_bar.php'; ?>

            <section id="main" class="column">

                <h4 class="alert_info">Selamat Datang <strong>PT. Srimurni Surabaya</strong>  </h4> 

                <article class="module width_full">

                    <div class="module_content">
                        <main>
                            <article>
                                <section>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-8 offset-md-2 mt-5">

                                                <a href="<?php echo base_url() ?>rekap">
                                                    <button class="btn btn-flat btn-danger mb-3">Kembali</button>
                                                </a>

                                                <?php if (isset($_GET['success'])) {
                                                    if ($_GET['success'] == '1') { ?>
                                                        <div class="alert alert-success text-center">Data berhasil ditambahkan</div>
                                                    <?php } else { ?>
                                                        <div class="alert alert-danger text-center">Data gagal ditambahkan</div>
                                                    <?php } ?>
                                                <?php } ?>

                                                <form action="<?php echo base_url()?>add_act_rekap_stock" method="post">
                                                    <div class="form-group">
                                                        <input type="text" name="section" id="section" class="form-control" placeholder="Kode Section">
                                                    </div>
                                                    <div class="form-group">
                                                    	<textarea name="deskripsi" id="deskripsi" class="form-control" placeholder="Deskripsi"></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" name="warna" id="warna"    class="form-control" placeholder="Warna">
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" name="ukuran" id="ukuran" class="form-control" placeholder="Ukuran (mm)">
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Quantity</label>
                                                        <hr>
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" name="masuk" id="masuk" onchange="masukChange(this.value)" class="form-control" placeholder="Masuk">
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" name="keluar" id="keluar" onchange="keluarChange(this.value)" class="form-control" placeholder="Keluar">
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" name="saldo" id="saldo" readonly="readonly" class="form-control" placeholder="Saldo">
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" name="lokasi_rak" id="lokasi_rak"    class="form-control" placeholder="Lokasi rak / Ket">
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="text" name="berat" id="berat"    class="form-control" placeholder="Berat (KG/M)">
                                                    </div>

                                                    <div class="form-group">
                                                        <button type="submit" name="submit" value="submit" class="btn btn-flat btn-success w-100">Tambah</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </article>
                        </main>

                        <div class="clear"></div>
                    </div>
                </article> <!-- end of stats article -->
            </div> 

            <div class="clear"></div>

            <div class="spacer"></div>


        </section>
    </div>
</div>

<?php require_once './template/metajs.php' ?>
<script type="text/javascript">
    function masukChange(val) {
        var val_keluar = document.getElementById("keluar").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val - val_keluar;
        saldo.setAttribute('value', val_saldo);
    }
    function keluarChange(val) {
        var val_masuk = document.getElementById("masuk").value;
        var saldo = document.getElementById("saldo");
        var val_saldo = val_masuk - val;
        saldo.setAttribute('value', val_saldo);
    }
</script>
</body>
</html>