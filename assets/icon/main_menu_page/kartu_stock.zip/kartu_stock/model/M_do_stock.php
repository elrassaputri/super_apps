<?php

/**
 * 
 */
class M_do_stock extends m_controller
{
	public function add($data) {
		$kode_do_stock_master 	= $data['kode_do_stock_master'];
		$tanggal_do_stock 		= $data['tanggal_do_stock'];
		$tujuan_do_stock 		= $data['tujuan_do_stock'];
		$nama_proyek_do_stock 	= $data['nama_proyek_do_stock'];
		$alamat_do_stock 		= $data['alamat_do_stock'];
		$penerima_do_stock 		= $data['penerima_do_stock'];
		$no_telp_do_stock 		= $data['no_telp_do_stock'];
		self::query("INSERT INTO `do_stock_master`(`kode_do_stock_master`, `tanggal_do_stock`, `tujuan_do_stock`,`nama_proyek_do_stock`, `alamat_do_stock`, `penerima_do_stock`, `no_telp_do_stock`) VALUES ('$kode_do_stock_master','$tanggal_do_stock','$tujuan_do_stock','$nama_proyek_do_stock','$alamat_do_stock','$penerima_do_stock','$no_telp_do_stock')");
	}

	public function delete($id) {
		$data = self::query("SELECT * FROM `do_stock_master` WHERE do_stock_master_id = $id");
		foreach ($data as $key => $value) {
			$kode_do_stock_master = $value['kode_do_stock_master'];
		}
		self::query("DELETE FROM `do_stock_master` WHERE do_stock_master_id = $id");
		self::query("DELETE FROM `do_stock_order` WHERE kode_do_stock_master = $kode_do_stock_master");
	}

	public function update($id, $data) {
		$kode_do_stock_master 	= $data['kode_do_stock_master'];
		$tanggal_do_stock 		= $data['tanggal_do_stock'];
		$tujuan_do_stock 		= $data['tujuan_do_stock'];
		$nama_proyek_do_stock 	= $data['nama_proyek_do_stock'];
		$alamat_do_stock 		= $data['alamat_do_stock'];
		$penerima_do_stock 		= $data['penerima_do_stock'];
		$no_telp_do_stock 		= $data['no_telp_do_stock'];
		self::query("UPDATE `do_stock_master` SET `kode_do_stock_master` = '$kode_do_stock_master', `tanggal_do_stock` = '$tanggal_do_stock', `tujuan_do_stock` = '$tujuan_do_stock',`nama_proyek_do_stock` = '$nama_proyek_do_stock', `alamat_do_stock` = '$alamat_do_stock', `penerima_do_stock` = '$penerima_do_stock', `no_telp_do_stock` = '$no_telp_do_stock' WHERE `do_stock_master_id`=$id");
	}

	public function get_search($cari) {
		$data = self::query("SELECT * FROM `do_stock_master` WHERE (`do_stock_master_id` LIKE '%$cari%' || `kode_do_stock_master` LIKE '%$cari%' || `tanggal_do_stock` LIKE '%$cari%' || `tujuan_do_stock` LIKE '%$cari%' || `nama_proyek_do_stock` LIKE '%$cari%' || `alamat_do_stock` LIKE '%$cari%' || `penerima_do_stock` LIKE '%$cari%' || `no_telp_do_stock` LIKE '%$cari%')");
		return $data;
	}

	public function get_search_limit($cari, $limitStart, $limitCount) {
		$data = self::query("SELECT * FROM `do_stock_master` WHERE (`do_stock_master_id` LIKE '%$cari%' || `kode_do_stock_master` LIKE '%$cari%' || `tanggal_do_stock` LIKE '%$cari%' || `tujuan_do_stock` LIKE '%$cari%' || `nama_proyek_do_stock` LIKE '%$cari%' || `alamat_do_stock` LIKE '%$cari%' || `penerima_do_stock` LIKE '%$cari%' || `no_telp_do_stock` LIKE '%$cari%') LIMIT $limitStart,$limitCount");
		return $data;
	}

	public function addKeranjang($data) {
		session_start();
		$lpb_material_id 		= $data['lpb_material_id'];
		$nama_material 		= $data['nama_material'];
		$kode_do_stock 		= $data['kode_do_stock'];
		$pjg_do_stock 		= $data['pjg_do_stock'];
		$finish_do_stock 	= $data['finish_do_stock'];
		$budget_do_stock 	= $data['budget_do_stock'];
		$vol_do_stock 		= $data['vol_do_stock'];
		$type_do_stock 		= $data['type_do_stock'];
		$ket_do_stock 		= $data['ket_do_stock'];
		self::query("INSERT INTO `do_stock_keranjang`(`nama_material`, `kode_do_stock`, `pjg_do_stock`,`finish_do_stock`, `budget_do_stock`, `vol_do_stock`, `type_do_stock`,`ket_do_stock`,`lpb_material_id`) VALUES ('$nama_material','$kode_do_stock','$pjg_do_stock','$finish_do_stock','$budget_do_stock','$vol_do_stock','$type_do_stock','$ket_do_stock','$lpb_material_id')");
	}

	public function deleteKeranjang($id) {
		self::query("DELETE FROM `do_stock_keranjang` WHERE do_stock_keranjang_id = $id");
	}

	public function copyTable($tableFrom='', $tableTo='', $transaksimaster_id='')
	{
		session_start();
		$data = self::query("SELECT * FROM $tableFrom");
		foreach ($data as $key => $value) {
			$lpb_material_id 		= $value['lpb_material_id'];
			$nama_material 		= $value['nama_material'];
			$kode_do_stock 		= $value['kode_do_stock'];
			$pjg_do_stock 		= $value['pjg_do_stock'];
			$finish_do_stock 	= $value['finish_do_stock'];
			$budget_do_stock 	= $value['budget_do_stock'];
			$vol_do_stock 		= $value['vol_do_stock'];
			$type_do_stock 		= $value['type_do_stock'];
			$ket_do_stock 		= $value['ket_do_stock'];
			$no_do 				= $transaksimaster_id;

			self::query("INSERT INTO `$tableTo`(`nama_material`, `kode_do_stock`, `pjg_do_stock`,`finish_do_stock`, `budget_do_stock`, `vol_do_stock`, `type_do_stock`,`ket_do_stock`, `kode_do_stock_master`,`lpb_material_id`) VALUES ('$nama_material','$kode_do_stock','$pjg_do_stock','$finish_do_stock','$budget_do_stock','$vol_do_stock','$type_do_stock','$ket_do_stock', '$no_do','$lpb_material_id')");
			self::query("TRUNCATE TABLE `$tableFrom`");
		}
	}

	public function addMaster($data)
	{
		session_start();
		$no_do 			= $data['no_do'];
		$tanggal_do 	= $data['tanggal_do'];
		$tujuan_do 		= $data['tujuan_do'];
		$nama_proyek 	= $data['nama_proyek'];
		$alamat_do 		= $data['alamat_do'];
		$penerima_do 	= $data['penerima_do'];
		$no_telp_do 	= $data['no_telp_do'];

		self::query("INSERT INTO `do_stock_master`(`kode_do_stock_master`, `tanggal_do_stock`, `tujuan_do_stock`,`nama_proyek_do_stock`, `alamat_do_stock`, `penerima_do_stock`, `no_telp_do_stock`) VALUES ('$no_do','$tanggal_do','$tujuan_do','$nama_proyek','$alamat_do','$penerima_do','$no_telp_do')");
		unset($_SESSION["no_do"]);
	}
}
?>