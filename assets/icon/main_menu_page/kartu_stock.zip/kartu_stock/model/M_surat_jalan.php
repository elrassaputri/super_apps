<?php

/**
 * 
 */
class M_surat_jalan extends m_controller
{

	public function add($data) {
		$kode_surat_jalan 		= $data['kode_surat_jalan'];
		$tanggal 				= $data['tanggal'];
		$tujuan 				= $data['tujuan'];
		$nama_proyek 			= $data['nama_proyek'];
		$alamat 				= $data['alamat'];
		$penerima 				= $data['penerima'];
		$no_telp 				= $data['no_telp'];
		$kode_do_stock_master 	= $data['kode_do_stock_master'];
		// self::query("INSERT INTO `lpb`(`lpb_nomor`, `lpb_date`, `lpb_proyek`,`lpb_lokasi`, `lpb_nama_supplier`, `lpb_material`, `lpb_section`,`lpb_warna`, `lpb_ukuran_1`,`lpb_vol`, `lpb_sat`) VALUES ('$lpb_nomor','$lpb_date','$lpb_proyek','$lpb_lokasi','$lpb_nama_supplier','$lpb_material','$lpb_section','$lpb_warna','$lpb_ukuran','$lpb_vol','$lpb_sat')");
	}

	public function delete($id) {
		$data = self::query("SELECT * FROM `surat_jalan_master` WHERE surat_jalan_id = $id");
		foreach ($data as $key => $value) {
			$kode_surat_jalan = $value['kode_surat_jalan'];
			$kode_do_stock_master = $value['kode_do_stock_master'];
		}
		self::query("DELETE FROM `surat_jalan_material` WHERE kode_surat_jalan_master = $kode_surat_jalan");
		self::query("DELETE FROM `do_stock_master` WHERE kode_do_stock_master = $kode_do_stock_master");
		self::query("DELETE FROM `do_stock_order` WHERE kode_do_stock_master = $kode_do_stock_master");
		self::query("DELETE FROM `surat_jalan_master` WHERE surat_jalan_id = $id");
	}

	public function update($id, $data) {
		$kode_surat_jalan 		= $data['kode_surat_jalan'];
		$tanggal 				= $data['tanggal'];
		$tujuan 				= $data['tujuan'];
		$nama_proyek 			= $data['nama_proyek'];
		$alamat 				= $data['alamat'];
		$penerima 				= $data['penerima'];
		$no_telp 				= $data['no_telp'];
		$kode_do_stock_master 	= $data['kode_do_stock_master'];
		// self::query("UPDATE `lpb` SET `lpb_nomor` = '$lpb_nomor', `lpb_date` = '$lpb_date', `lpb_proyek` = '$lpb_proyek',`lpb_lokasi` = '$lpb_lokasi', `lpb_nama_supplier` = '$lpb_nama_supplier', `lpb_material` = '$lpb_material', `lpb_section` = '$lpb_section',`lpb_warna` = '$lpb_warna', `lpb_ukuran_1` = '$lpb_ukuran',`lpb_vol` = '$lpb_vol', `lpb_sat` = '$lpb_sat' WHERE `lpb_id`=$id");
	}

	public function get_search($cari) {
		$data = self::query("SELECT * FROM `surat_jalan_master` WHERE (`kode_surat_jalan` LIKE '%$cari%' || `tanggal` LIKE '%$cari%' || `tujuan` LIKE '%$cari%' || `nama_proyek` LIKE '%$cari%' || `alamat` LIKE '%$cari%' || `penerima` LIKE '%$cari%' || `no_telp` LIKE '%$cari%' || `kode_do_stock_master` LIKE '%$cari%')");
		return $data;
	}

	public function get_search_limit($cari, $limitStart, $limitCount) {
		$data = self::query("SELECT * FROM `surat_jalan_master` WHERE (`kode_surat_jalan` LIKE '%$cari%' || `tanggal` LIKE '%$cari%' || `tujuan` LIKE '%$cari%' || `nama_proyek` LIKE '%$cari%' || `alamat` LIKE '%$cari%' || `penerima` LIKE '%$cari%' || `no_telp` LIKE '%$cari%' || `kode_do_stock_master` LIKE '%$cari%') LIMIT $limitStart,$limitCount");
		return $data;
	}
	
	public function add_master($data) {
		$kode_surat_jalan 		= $data['kode_surat_jalan'];
		$tanggal 				= $data['tanggal'];
		$tujuan 				= $data['tujuan'];
		$nama_proyek 			= $data['nama_proyek'];
		$alamat 				= $data['alamat'];
		$penerima 				= $data['penerima'];
		$no_telp 				= $data['no_telp'];
		$kode_do_stock_master 	= $data['kode_do_stock_master'];
		// self::query("INSERT INTO `surat_jalan_master`(`kode_surat_jalan`, `tanggal`, `tujuan`, `nama_proyek`, `alamat`, `penerima`, `no_telp`, `kode_do_stock_master`) VALUES ('$kode_surat_jalan','$tanggal','$tujuan','$nama_proyek','$alamat','$penerima','$no_telp','$kode_do_stock_master')");
	}

	public function add_material($data) {
		$kode_surat_jalan_master 	= $data['kode_surat_jalan_master'];
		$data_update 				= $data['data_update'];
		
		for ($i=0; $i < count($data_update['id']); $i++) { 
			$id 			= $data_update['id'][$i];
			$id_lpb 		= $data_update['id_lpb'][$i];
			$value 			= $data_update['value'][$i];
			$kode_do_stock 	= $data_update['kode_do_stock'][$i];
			$nama_material 	= $data_update['nama_material'][$i];

			self::query("INSERT INTO `surat_jalan_material`(`kode_surat_jalan_master`, `kode_do_stock`, `nama_material`, `vol`) VALUES ('$kode_surat_jalan_master','$kode_do_stock','$nama_material','$value')");

			self::query("UPDATE `lpb` SET `lpb_vol` = (`lpb_vol` - $value) WHERE `lpb_id` = $id_lpb");

			self::query("UPDATE `do_stock_order` SET `vol_do_stock` = (`vol_do_stock` - $value) WHERE `lpb_material_id` = $id_lpb");
		}
	}

	public function delete($id) {
		self::query("DELETE FROM `lpb` WHERE lpb_id = $id");
	}

	public function update($id, $data) {
		$lpb_nomor 			= $data['lpb_nomor'];
		$lpb_date 			= $data['lpb_date'];
		$lpb_proyek 		= $data['lpb_proyek'];
		$lpb_lokasi 		= $data['lpb_lokasi'];
		$lpb_nama_supplier 	= $data['lpb_nama_supplier'];
		$lpb_material 		= $data['lpb_material'];
		$lpb_section 		= $data['lpb_section'];
		$lpb_warna 			= $data['lpb_warna'];
		$lpb_ukuran 		= $data['lpb_ukuran'];
		$lpb_vol 			= $data['lpb_vol'];
		$lpb_sat 			= $data['lpb_sat'];
		self::query("UPDATE `lpb` SET `lpb_nomor` = '$lpb_nomor', `lpb_date` = '$lpb_date', `lpb_proyek` = '$lpb_proyek',`lpb_lokasi` = '$lpb_lokasi', `lpb_nama_supplier` = '$lpb_nama_supplier', `lpb_material` = '$lpb_material', `lpb_section` = '$lpb_section',`lpb_warna` = '$lpb_warna', `lpb_ukuran_1` = '$lpb_ukuran',`lpb_vol` = '$lpb_vol', `lpb_sat` = '$lpb_sat' WHERE `lpb_id`=$id");
	}

	public function get_search($cari) {
		$data = self::query("SELECT * FROM `lpb` WHERE (`lpb_id` LIKE '%$cari%' || `lpb_nomor` LIKE '%$cari%' || `lpb_date` LIKE '%$cari%' || `lpb_proyek` LIKE '%$cari%' || `lpb_lokasi` LIKE '%$cari%' || `lpb_nama_supplier` LIKE '%$cari%' || `lpb_material` LIKE '%$cari%' || `lpb_section` LIKE '%$cari%' || `lpb_warna` LIKE '%$cari%' || `lpb_ukuran_1` LIKE '%$cari%' || `lpb_vol` LIKE '%$cari%' || `lpb_sat` LIKE '%$cari%')");
		return $data;
	}

	public function get_search_limit($cari, $limitStart, $limitCount) {
		$data = self::query("SELECT * FROM `lpb` WHERE (`lpb_id` LIKE '%$cari%' || `lpb_nomor` LIKE '%$cari%' || `lpb_date` LIKE '%$cari%' || `lpb_proyek` LIKE '%$cari%' || `lpb_lokasi` LIKE '%$cari%' || `lpb_nama_supplier` LIKE '%$cari%' || `lpb_material` LIKE '%$cari%' || `lpb_section` LIKE '%$cari%' || `lpb_warna` LIKE '%$cari%' || `lpb_ukuran_1` LIKE '%$cari%' || `lpb_vol` LIKE '%$cari%' || `lpb_sat` LIKE '%$cari%') LIMIT $limitStart,$limitCount");
		return $data;
	}
}
?>