<?php

/**
 * 
 */
class M_kartu_stock extends m_controller
{
	
	public function add($data) {
		$tanggal = $data['tanggal'];
		$no_sj = $data['no_sj'];
		$no_lpb = $data['no_lpb'];
		$nama_supplier = $data['nama_supplier'];
		$masuk = $data['masuk'];
		$keluar = $data['keluar'];
		$saldo = $data['saldo'];
		$pjg = $data['pjg'];
		$qty = $data['qty'];
		$ket = $data['ket'];
		self::query("INSERT INTO `kartu_stock`(`tanggal`, `no_sj`, `no_lpb`,`nama_supplier`, `masuk`, `keluar`,`saldo`, `pjg`,`qty`, `ket`) VALUES ('$tanggal','$no_sj','$no_lpb','$nama_supplier','$masuk','$keluar','$saldo','$pjg','$qty','$ket')");
	}

	public function delete($id) {
		self::query("DELETE FROM `kartu_stock` WHERE id = $id");
	}

	public function update($id, $data) {
		$tanggal = $data['tanggal'];
		$no_sj = $data['no_sj'];
		$no_lpb = $data['no_lpb'];
		$nama_supplier = $data['nama_supplier'];
		$masuk = $data['masuk'];
		$keluar = $data['keluar'];
		$saldo = $data['saldo'];
		$pjg = $data['pjg'];
		$qty = $data['qty'];
		$ket = $data['ket'];
		self::query("UPDATE `kartu_stock` SET `tanggal` = '$tanggal', `no_sj` = '$no_sj', `no_lpb` = '$no_lpb',`nama_supplier` = '$nama_supplier', `masuk` = '$masuk', `keluar` = '$keluar',`saldo` = '$saldo', `pjg` = '$pjg',`qty` = '$qty', `ket` = '$ket' WHERE `id`=$id");
	}

	public function get_search($cari) {
		$data = self::query("SELECT * FROM `kartu_stock` WHERE (`id` LIKE '%$cari%' || `tanggal` LIKE '%$cari%' || `no_sj` LIKE '%$cari%' || `no_lpb` LIKE '%$cari%' || `nama_supplier` LIKE '%$cari%' || `masuk` LIKE '%$cari%' || `keluar` LIKE '%$cari%' || `saldo` LIKE '%$cari%' || `pjg` LIKE '%$cari%' || `qty` LIKE '%$cari%' || `ket` LIKE '%$cari%')");
		return $data;
	}

	public function get_search_limit($cari, $limitStart, $limitCount) {
		$data = self::query("SELECT * FROM `kartu_stock` WHERE (`id` LIKE '%$cari%' || `tanggal` LIKE '%$cari%' || `no_sj` LIKE '%$cari%' || `no_lpb` LIKE '%$cari%' || `nama_supplier` LIKE '%$cari%' || `masuk` LIKE '%$cari%' || `keluar` LIKE '%$cari%' || `saldo` LIKE '%$cari%' || `pjg` LIKE '%$cari%' || `qty` LIKE '%$cari%' || `ket` LIKE '%$cari%') LIMIT $limitStart,$limitCount");
		return $data;
	}
}
?>