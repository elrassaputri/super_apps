<?php

/**
 * 
 */
class M_data_stock extends m_controller
{
	
	public function add($data) {
		$lpb_nomor 			= $data['lpb_nomor'];
		$lpb_date 			= $data['lpb_date'];
		$lpb_proyek 		= $data['lpb_proyek'];
		$lpb_lokasi 		= $data['lpb_lokasi'];
		$lpb_nama_supplier 	= $data['lpb_nama_supplier'];
		$lpb_material 		= $data['lpb_material'];
		$lpb_section 		= $data['lpb_section'];
		$lpb_warna 			= $data['lpb_warna'];
		$lpb_ukuran 		= $data['lpb_ukuran'];
		$lpb_vol 			= $data['lpb_vol'];
		$lpb_sat 			= $data['lpb_sat'];
		self::query("INSERT INTO `lpb`(`lpb_nomor`, `lpb_date`, `lpb_proyek`,`lpb_lokasi`, `lpb_nama_supplier`, `lpb_material`, `lpb_section`,`lpb_warna`, `lpb_ukuran_1`,`lpb_vol`, `lpb_sat`) VALUES ('$lpb_nomor','$lpb_date','$lpb_proyek','$lpb_lokasi','$lpb_nama_supplier','$lpb_material','$lpb_section','$lpb_warna','$lpb_ukuran','$lpb_vol','$lpb_sat')");
	}

	public function delete($id) {
		self::query("DELETE FROM `lpb` WHERE lpb_id = $id");
	}

	public function update($id, $data) {
		$lpb_nomor 			= $data['lpb_nomor'];
		$lpb_date 			= $data['lpb_date'];
		$lpb_proyek 		= $data['lpb_proyek'];
		$lpb_lokasi 		= $data['lpb_lokasi'];
		$lpb_nama_supplier 	= $data['lpb_nama_supplier'];
		$lpb_material 		= $data['lpb_material'];
		$lpb_section 		= $data['lpb_section'];
		$lpb_warna 			= $data['lpb_warna'];
		$lpb_ukuran 		= $data['lpb_ukuran'];
		$lpb_vol 			= $data['lpb_vol'];
		$lpb_sat 			= $data['lpb_sat'];
		self::query("UPDATE `lpb` SET `lpb_nomor` = '$lpb_nomor', `lpb_date` = '$lpb_date', `lpb_proyek` = '$lpb_proyek',`lpb_lokasi` = '$lpb_lokasi', `lpb_nama_supplier` = '$lpb_nama_supplier', `lpb_material` = '$lpb_material', `lpb_section` = '$lpb_section',`lpb_warna` = '$lpb_warna', `lpb_ukuran_1` = '$lpb_ukuran',`lpb_vol` = '$lpb_vol', `lpb_sat` = '$lpb_sat' WHERE `lpb_id`=$id");
	}

	public function get_search($cari) {
		$data = self::query("SELECT * FROM `lpb` WHERE (`lpb_id` LIKE '%$cari%' || `lpb_nomor` LIKE '%$cari%' || `lpb_date` LIKE '%$cari%' || `lpb_proyek` LIKE '%$cari%' || `lpb_lokasi` LIKE '%$cari%' || `lpb_nama_supplier` LIKE '%$cari%' || `lpb_material` LIKE '%$cari%' || `lpb_section` LIKE '%$cari%' || `lpb_warna` LIKE '%$cari%' || `lpb_ukuran_1` LIKE '%$cari%' || `lpb_vol` LIKE '%$cari%' || `lpb_sat` LIKE '%$cari%')");
		return $data;
	}

	public function get_search_limit($cari, $limitStart, $limitCount) {
		$data = self::query("SELECT * FROM `lpb` WHERE (`lpb_id` LIKE '%$cari%' || `lpb_nomor` LIKE '%$cari%' || `lpb_date` LIKE '%$cari%' || `lpb_proyek` LIKE '%$cari%' || `lpb_lokasi` LIKE '%$cari%' || `lpb_nama_supplier` LIKE '%$cari%' || `lpb_material` LIKE '%$cari%' || `lpb_section` LIKE '%$cari%' || `lpb_warna` LIKE '%$cari%' || `lpb_ukuran_1` LIKE '%$cari%' || `lpb_vol` LIKE '%$cari%' || `lpb_sat` LIKE '%$cari%') LIMIT $limitStart,$limitCount");
		return $data;
	}
}
?>