<?php

/**
 * 
 */
class M_rekap_stock extends m_controller
{
	
	public function add($data) {
		$section = $data['section'];
		$deskripsi = $data['deskripsi'];
		$warna = $data['warna'];
		$ukuran = $data['ukuran'];
		$masuk = $data['masuk'];
		$keluar = $data['keluar'];
		$saldo = $data['saldo'];
		$lokasi_rak = $data['lokasi_rak'];
		$berat = $data['berat'];
		self::query("INSERT INTO `rekap_stock`(`section`, `deskripsi`, `warna`,`ukuran`, `masuk`, `keluar`,`saldo`, `lokasi_rak`,`berat`) VALUES ('$section','$deskripsi','$warna','$ukuran','$masuk','$keluar','$saldo','$lokasi_rak','$berat')");
	}

	public function delete($id) {
		self::query("DELETE FROM `rekap_stock` WHERE id = $id");
	}

	public function update($id, $data) {
		$section = $data['section'];
		$deskripsi = $data['deskripsi'];
		$warna = $data['warna'];
		$ukuran = $data['ukuran'];
		$masuk = $data['masuk'];
		$keluar = $data['keluar'];
		$saldo = $data['saldo'];
		$lokasi_rak = $data['lokasi_rak'];
		$berat = $data['berat'];
		self::query("UPDATE `rekap_stock` SET `section` = '$section', `deskripsi` = '$deskripsi', `warna` = '$warna',`ukuran` = '$ukuran', `masuk` = '$masuk', `keluar` = '$keluar',`saldo` = '$saldo', `lokasi_rak` = '$lokasi_rak',`berat` = '$berat' WHERE `id`=$id");
	}

	public function get_search($cari) {
		$data = self::query("SELECT * FROM `rekap_stock` WHERE (`id` LIKE '%$cari%' || `section` LIKE '%$cari%' || `deskripsi` LIKE '%$cari%' || `warna` LIKE '%$cari%' || `ukuran` LIKE '%$cari%' || `masuk` LIKE '%$cari%' || `keluar` LIKE '%$cari%' || `saldo` LIKE '%$cari%' || `lokasi_rak` LIKE '%$cari%' || `berat` LIKE '%$cari%')");
		return $data;
	}

	public function get_search_limit($cari, $limitStart, $limitCount) {
		$data = self::query("SELECT * FROM `rekap_stock` WHERE (`id` LIKE '%$cari%' || `section` LIKE '%$cari%' || `deskripsi` LIKE '%$cari%' || `warna` LIKE '%$cari%' || `ukuran` LIKE '%$cari%' || `masuk` LIKE '%$cari%' || `keluar` LIKE '%$cari%' || `saldo` LIKE '%$cari%' || `lokasi_rak` LIKE '%$cari%' || `berat` LIKE '%$cari%') LIMIT $limitStart,$limitCount");
		return $data;
	}
}
?>