import 'package:flutter/material.dart';

class Api{
  static var host = "http://10.204.100.120/super/";
  static var app_login = host+"app_login.php";
}
