//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <google_maps_flutter/GoogleMapsPlugin.h>
#import <imei_plugin/ImeiPlugin.h>
#import <location/LocationPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FLTGoogleMapsPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTGoogleMapsPlugin"]];
  [ImeiPlugin registerWithRegistrar:[registry registrarForPlugin:@"ImeiPlugin"]];
  [LocationPlugin registerWithRegistrar:[registry registrarForPlugin:@"LocationPlugin"]];
}

@end
